import '../../../../utils/library.dart';

class UpcomingBookingShimmer extends StatelessWidget {
  const UpcomingBookingShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
