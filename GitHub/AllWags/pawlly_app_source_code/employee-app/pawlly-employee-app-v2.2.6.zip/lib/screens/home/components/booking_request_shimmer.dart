import '../../../../utils/library.dart';

class BookingRequestShimmer extends StatelessWidget {
  const BookingRequestShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
