import '../../../../utils/library.dart';

class DashboardScreenShimmer extends StatelessWidget {
  const DashboardScreenShimmer({super.key});

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
